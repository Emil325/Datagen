# testing data generation via SQL interface
../bin/sqldata -sql "select account, account_code, account_type, account_subtype, customer, customer_type, today, address, city, state, phone, credit_card, ssn, driver_lic, mony, product, price, timestamp" -limit 10 -message-type TEST -id
