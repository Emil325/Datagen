# test Kafka Producer and Consumer Group
../bin/run-producer-tests -job-config ../user/emil-kafka-tests.cfg -broker-config ../user/default-kafka-broker.cfg
